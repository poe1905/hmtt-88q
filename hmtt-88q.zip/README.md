# hmtt-88q

## 下载依赖
```
npm install
```

### 启动这个项目
```
npm run serve
```

### 编译和缩小以供生产

```
npm run build
```

### Lints和fixes文件

```
npm run lint
```

### 自定义配置
See [Configuration Reference](https://cli.vuejs.org/config/).
